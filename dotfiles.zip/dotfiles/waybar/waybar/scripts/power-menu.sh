#!/usr/bin/env bash

# kilit komutunu tespit et (hyprlock > swaylock > loginctl)
if command -v hyprlock >/dev/null 2>&1; then
  LOCK_CMD="hyprlock"
elif command -v swaylock >/dev/null 2>&1; then
  LOCK_CMD="swaylock"
else
  LOCK_CMD="loginctl lock-session"
fi

# Menü seçenekleri
CHOICE=$(printf "🔒 Kilitle\n🚪 Oturumu Kapat\n🔁 Yeniden Başlat\n🔴 Kapat" | rofi -dmenu -i -p "Güç Menüsü")

case "$CHOICE" in
  "🔒 Kilitle")
    $LOCK_CMD
    ;;
  "🚪 Oturumu Kapat")
    # hyprland için hyprctl dispatch exit, yoksa loginctl terminate-user
    if command -v hyprctl >/dev/null 2>&1; then
      hyprctl dispatch exit
    else
      loginctl terminate-user "$USER"
    fi
    ;;
  "🔁 Yeniden Başlat")
    systemctl reboot
    ;;
  "🔴 Kapat")
    systemctl poweroff
    ;;
  *)
    exit 0
    ;;
esac
