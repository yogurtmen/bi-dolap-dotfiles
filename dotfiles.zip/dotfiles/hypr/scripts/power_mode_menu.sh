#!/bin/bash

# Mevcut güç modunu al
current=$(powerprofilesctl get)

# Menü seçenekleri
options=("performance" "balanced" "power-saver")

# Menü oluştur
menu=""
for opt in "${options[@]}"; do
    if [ "$opt" = "$current" ]; then
        menu+="✅ $opt\n"
    else
        menu+="$opt\n"
    fi
done

# Rofi menüsünü göster
selected=$(echo -e "$menu" | rofi -dmenu -p "Güç Modu Seç:" | sed 's/✅ //')

# Seçim varsa modu değiştir
if [[ -n "$selected" ]]; then
    powerprofilesctl set "$selected"
fi
